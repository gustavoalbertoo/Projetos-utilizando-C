// Integrantes:
// - Gabriel da Silva Coelho (10748434)
// - Gabriel Mello Aristides (10736402)
// - Gustavo Rodrigues Alberto (10738010)
// - Rafael Dantas de Moraes (10736655)

#include <stddef.h>
#include <stdio.h>1
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX 200000

typedef struct {
  int ano;
  char nome[20];
  char disciplina[20];
  float media;
} Registro;

// remove espaços e quebras de linha do final de uma string
static void removerExtremosRedundantes(char *s) {
  int len;
  if (!s)
    return;
  len = strlen(s);
  while (len > 0 &&
         (s[len - 1] == '\n' || s[len - 1] == '\r' || s[len - 1] == ' ')) {
    s[--len] = '\0';
  }
}

// carrega registros do csv
int carregarCSV(const char *linha, Registro *c) {
  char copy[512];
  char *campos[4];
  int n = 0;
  char *token;

  strncpy(copy, linha, sizeof(copy) - 1);
  copy[sizeof(copy) - 1] = '\0';

  token = strtok(copy, ",");
  while (token && n < 4) {
    campos[n++] = token;
    token = strtok(NULL, ",");
  }

  if (n < 4)
    return 0;

  c->ano = atoi(campos[0]);
  strncpy(c->nome, campos[1], sizeof(c->nome) - 1);
  c->nome[sizeof(c->nome) - 1] = '\0';
  strncpy(c->disciplina, campos[2], sizeof(c->disciplina) - 1);
  c->disciplina[sizeof(c->disciplina) - 1] = '\0';
  c->media = atof(campos[3]);

  removerExtremosRedundantes(c->nome);
  removerExtremosRedundantes(c->disciplina);

  return 1;
}

// carrega linhas do arquivo
void carregarRegistros(Registro *lista, int *lista_sz) {
  *lista_sz = 0;

  char linha[512];
  FILE *arq = fopen("entrada.csv", "r");
  if (arq != NULL) {
    while (fgets(linha, sizeof(linha), arq) && *lista_sz < MAX) {
      if (carregarCSV(linha, &lista[*lista_sz])) {
        (*lista_sz)++;
      }
    }
    fclose(arq);
  }
}

// troca dois registros
void trocar(Registro *a, Registro *b) {
  Registro temp = *a;
  *a = *b;
  *b = temp;
}

// salva a lista atualizada no arquivo de entrada
void salvarEntrada(Registro lista[], int lista_sz) {
  int i;
  FILE *arq = fopen("entrada.csv", "w");
  if (arq == NULL)
    return;

  for (i = 0; i < lista_sz; i++) {
    fprintf(arq, "%d,%s,%s,%.1f\n", lista[i].ano, lista[i].nome,
            lista[i].disciplina, lista[i].media);
  }
  fclose(arq);
}

// salva a lista ordenada no arquivo de saída
void salvarSaida(Registro lista[], int lista_sz) {
  int i;
  FILE *arq = fopen("saida.csv", "w");
  if (arq == NULL)
    return;

  for (i = 0; i < lista_sz; i++) {
    fprintf(arq, "%d,%s,%s,%.1f\n", lista[i].ano, lista[i].nome,
            lista[i].disciplina, lista[i].media);
  }
  fclose(arq);
  printf("\nArquivo saida.csv gerado!\n");
}

// gera entrada aleatória e salva em entrada.csv
void gerarEntradaAleatoria(Registro lista[], int *lista_sz) {
  int n, i, num_aleatorio;
  char nomes_base[][20] = {
      "João",  "Maria",    "José",    "Ana",    "Carlos",   "Beatriz",
      "Diego", "Fernanda", "Gabriel", "Helena", "Igor",     "Joana",
      "Kevin", "Larissa",  "Matheus", "Nicole", "Priscila", "Rafaela"};
  char disciplinas[][20] = {"matemática", "português", "geografia"};
  int num_nomes = sizeof(nomes_base) / sizeof(nomes_base[0]);
  int num_disciplinas = sizeof(disciplinas) / sizeof(disciplinas[0]);

  printf("\nQuantos registros deseja gerar? ");
  scanf("%d", &n);

  if (n <= 0 || n > MAX) {
    printf("Número inválido! Deve estar entre 1 e %d.\n", MAX);
    return;
  }

  *lista_sz = 0;
  srand(time(NULL));

  for (i = 0; i < n; i++) {
    lista[i].ano = 2010 + rand() % 14;
    num_aleatorio = rand() % 1000;
    sprintf(lista[i].nome, "%s%d", nomes_base[rand() % num_nomes],
            num_aleatorio);
    strcpy(lista[i].disciplina, disciplinas[rand() % num_disciplinas]);
    lista[i].media = (rand() % 1001) / 100.0;
    (*lista_sz)++;
  }

  salvarEntrada(lista, *lista_sz);
  printf("\n%d registros gerados com sucesso!\n", *lista_sz);
}

// ordena nota por bubble sort
void ordenarNotaBubble(Registro lista[], int *lista_sz) {
  int i, j;
  long passos = 0;
  clock_t inicio, fim;
  double tempo_seg;

  if (*lista_sz == 0)
    return;

  inicio = clock();
  for (i = 0; i < *lista_sz - 1; i++) {
    for (j = 0; j < *lista_sz - i - 1; j++) {
      passos++;
      if (lista[j].media < lista[j + 1].media) {
        trocar(&lista[j], &lista[j + 1]);
      }
    }
  }
  fim = clock();
  tempo_seg = (double)(fim - inicio) / CLOCKS_PER_SEC;

  salvarSaida(lista, *lista_sz);
  printf("\nAlgoritmo: Bubble Sort\n");
  printf("Tamanho Entrada: %d\n", *lista_sz);
  printf("Tempo execução: %.6f segundos\n", tempo_seg);
  printf("Comparações (passos): %ld\n", passos);
}

// merge sort auxiliar
void merge(Registro lista[], int esq, int meio, int dir, long *passos) {
  int i = esq, j = meio + 1, k = 0;
  Registro *temp = (Registro *)malloc((dir - esq + 1) * sizeof(Registro));

  while (i <= meio && j <= dir) {
    (*passos)++;
    if (lista[i].media >= lista[j].media) {
      temp[k++] = lista[i++];
    } else {
      temp[k++] = lista[j++];
    }
  }

  while (i <= meio) {
    (*passos)++;
    temp[k++] = lista[i++];
  }

  while (j <= dir) {
    (*passos)++;
    temp[k++] = lista[j++];
  }

  for (i = esq, k = 0; i <= dir; i++, k++) {
    lista[i] = temp[k];
  }

  free(temp);
}

// ordena nota por merge sort
void mergeSort(Registro lista[], int esq, int dir, long *passos) {
  if (esq < dir) {
    int meio = (esq + dir) / 2;
    mergeSort(lista, esq, meio, passos);
    mergeSort(lista, meio + 1, dir, passos);
    merge(lista, esq, meio, dir, passos);
  }
}

// ordena por merge sort com contagem de passos e tempo
void ordenarNotaMerge(Registro lista[], int lista_sz) {
  long passos = 0;
  clock_t inicio, fim;
  double tempo_seg;

  if (lista_sz == 0)
    return;

  inicio = clock();
  mergeSort(lista, 0, lista_sz - 1, &passos);
  fim = clock();
  tempo_seg = (double)(fim - inicio) / CLOCKS_PER_SEC;

  salvarSaida(lista, lista_sz);
  printf("\nAlgoritmo: Merge Sort\n");
  printf("Tamanho Entrada: %d\n", lista_sz);
  printf("Tempo execução: %.6f segundos\n", tempo_seg);
  printf("Comparações (passos): %ld\n", passos);
}




 int main() {
  Registro *lista = malloc(MAX * sizeof(Registro));
  int lista_sz = 0;
  int op;

  carregarRegistros(lista, &lista_sz);

  do {
    printf("\n>>> MENU DE REGISTROS ESCOLARES (%d/%d)\n", lista_sz, MAX);
    printf("1 - Gerar entrada aleatória (entrada.csv)\n");
    printf("2 - Ordenar nota por bubble\n");
    printf("3 - Ordenar nota por merge\n");
    printf("0 - Sair\n");
    printf("Opcao: ");
    if (scanf("%d", &op) != 1)
      break;

    switch (op) {
    case 1:
      gerarEntradaAleatoria(lista, &lista_sz);
      break;
    case 2:
      carregarRegistros(lista, &lista_sz);
      ordenarNotaBubble(lista, &lista_sz);
      break;
    case 3:
      carregarRegistros(lista, &lista_sz);
      ordenarNotaMerge(lista, lista_sz);
      break;
    case 0:
      printf("Programa Finalizado!\n");
      break;
    }
  } while (op != 0);

  free(lista);
  return 0;
}
