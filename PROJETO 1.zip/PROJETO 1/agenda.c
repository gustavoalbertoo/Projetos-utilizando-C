// Integrantes:
// - Gabriel da Silva Coelho (10748434)
// - Gabriel Mello Aristides (10736402)
// - Gustavo Rodrigues Alberto (10738010)
// - Rafael Dantas de Moraes (10736655)

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX 500

// retorna o índice do primeiro caractere de s que é igual a qualquer caractere de candidatos
size_t strcspn(const char *s, const char *candidatos) {
    const char *p = s;

    while (*p) {
        const char *r = candidatos;
        while (*r) {
            if (*p == *r) {
                return (size_t)(p - s);
            }
            r++;
        }
        p++;
    }

    return (size_t)(p - s);
}

// compara as strings s1 e s2
int strcmp(const char *s1, const char *s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *s1 - *s2;
}

// retorna o tamanho da string s
size_t strlen(const char *s) {
    size_t len = 0;
    while (s[len]) {
        len++;
    }
    return len;
}

// copia uma string para outra, evitando estouro de buffer
char *strncpy(char *dest, const char *src, size_t n) {
    size_t i;
    for (i = 0; i < n && src[i] != '\0'; i++) {
        dest[i] = src[i];
    }
    for (; i < n; i++) {
        dest[i] = '\0';
    }
    return dest;
}

// implementação simplificada de strtok
static char *strtok_estado = NULL;
char *strtok(char *str, const char *delim) {
    if (str != NULL) {
        strtok_estado = str;
    }
    if (!strtok_estado || *strtok_estado == '\0') {
        return NULL;
    }

    char *token = strtok_estado;
    while (*strtok_estado && *strtok_estado != *delim) {
        strtok_estado++;
    }

    if (*strtok_estado == '\0') {
        strtok_estado = NULL;
        return token;
    }

    *strtok_estado = '\0';
    strtok_estado++;
    return token;
}

// define a estrutura de compromisso
typedef struct {
    int ano, mes, dia, hora, minuto;
    float duracao;
    int prioridade;
    char nome[100];
    char descricao[200];
    char local[100];
} Compromisso;

// troca dois compromissos
void trocar(Compromisso *a, Compromisso *b) {
    Compromisso temp = *a;
    *a = *b;
    *b = temp;
}

// valida data e hora
int validarDataHora(int d, int m, int h, int min) {
    if (m < 1 || m > 12) return 0;
    if (d < 1 || d > 31) return 0;
    if (h < 0 || h > 23) return 0; 
    if (min < 0 || min > 59) return 0;
    return 1;
}

// salva a lista atualizada no arquivo de entrada
void salvarEntrada(Compromisso lista[], int lista_sz) {
    int i;
    FILE *arq = fopen("entrada.csv", "w");
    if (arq == NULL) return;

    for (i = 0; i < lista_sz; i++) {
        fprintf(arq, "%d;%d;%d;%d;%d;%.2f;%d;%s;%s;%s\n", lista[i].ano,
                lista[i].mes, lista[i].dia, lista[i].hora, lista[i].minuto,
                lista[i].duracao, lista[i].prioridade, lista[i].nome,
                lista[i].descricao, lista[i].local);
    }
    fclose(arq);
}

// salva a lista ordenada no arquivo de saída
void salvarSaida(Compromisso lista[], int lista_sz) {
    int i;
    FILE *arq = fopen("saida.csv", "w");
    if (arq == NULL) return;

    for (i = 0; i < lista_sz; i++) {
        fprintf(arq, "%d;%d;%d;%d;%d;%.2f;%d;%s;%s;%s\n", lista[i].ano,
                lista[i].mes, lista[i].dia, lista[i].hora, lista[i].minuto,
                lista[i].duracao, lista[i].prioridade, lista[i].nome,
                lista[i].descricao, lista[i].local);
    }
    fclose(arq);
    printf("\nArquivo saida.csv gerado!\n");
}

// adiciona um compromisso à lista
void addCompromisso(Compromisso lista[], int *lista_sz) {
    Compromisso c;
    int data_valida = 0;

    if (*lista_sz >= MAX) {
        printf("Limite atingido!\n");
        return;
    }

    do {
        printf("\n--- Novo Compromisso ---\n");
        printf("Ano: "); scanf("%d", &c.ano);
        printf("Mes (1-12): "); scanf("%d", &c.mes);
        printf("Dia (1-31): "); scanf("%d", &c.dia);
        printf("Hora (0-23): "); scanf("%d", &c.hora);
        printf("Minuto (0-59): "); scanf("%d", &c.minuto);

        if (validarDataHora(c.dia, c.mes, c.hora, c.minuto)) {
            data_valida = 1;
        } else {
            printf("\nValores invalidos! Mes ate 12, Dia ate 31, Hora ate 23, Min ate 59.\n");
        }
    } while (!data_valida);

    printf("Duracao (horas): "); scanf("%f", &c.duracao);
    printf("Prioridade (1-5): "); scanf("%d", &c.prioridade);
    getchar(); 

    printf("Nome: "); fgets(c.nome, 100, stdin);
    c.nome[strcspn(c.nome, "\n")] = 0;
    printf("Descricao: "); fgets(c.descricao, 200, stdin);
    c.descricao[strcspn(c.descricao, "\n")] = 0;
    printf("Local: "); fgets(c.local, 100, stdin);
    c.local[strcspn(c.local, "\n")] = 0;

    lista[*lista_sz] = c;
    (*lista_sz)++;
    salvarEntrada(lista, *lista_sz);

    printf("\nCompromisso adicionado com sucesso!\n");
}

// remove um compromisso da lista
void removCompromisso(Compromisso lista[], int *lista_sz) {
    int i, pos;
    if (*lista_sz == 0) {
        printf("Agenda vazia!\n");
        return;
    }

    for (i = 0; i < *lista_sz; i++) {
        printf("%d - %s [%02d/%02d]\n", i, lista[i].nome, lista[i].dia, lista[i].mes);
    }
    printf("Escolha o indice: "); scanf("%d", &pos);

    if (pos < 0 || pos >= *lista_sz) return;

    for (i = pos; i < (*lista_sz) - 1; i++) {
        lista[i] = lista[i + 1];
    }

    (*lista_sz)--;
    salvarEntrada(lista, *lista_sz);
    printf("Removido!\n");
}

// ordena por data
void ordenarData(Compromisso lista[], int lista_sz) {
    int i, j;
    for (i = 0; i < lista_sz - 1; i++) {
        for (j = 0; j < lista_sz - i - 1; j++) {
            if (lista[j].ano > lista[j + 1].ano ||
                (lista[j].ano == lista[j + 1].ano && lista[j].mes > lista[j + 1].mes) ||
                (lista[j].ano == lista[j + 1].ano && lista[j].mes == lista[j + 1].mes && lista[j].dia > lista[j + 1].dia)) {
                trocar(&lista[j], &lista[j + 1]);
            }
        }
    }
    salvarSaida(lista, lista_sz);
}

// ordena por data e hora
void ordenarDataHora(Compromisso lista[], int lista_sz) {
    int i, j;
    for (i = 0; i < lista_sz - 1; i++) {
        for (j = 0; j < lista_sz - i - 1; j++) {
            long t1 = (long)lista[j].hora * 60 + lista[j].minuto;
            long t2 = (long)lista[j+1].hora * 60 + lista[j+1].minuto;
            long d1 = (long)lista[j].ano * 10000 + lista[j].mes * 100 + lista[j].dia;
            long d2 = (long)lista[j+1].ano * 10000 + lista[j+1].mes * 100 + lista[j+1].dia;

            if (d1 > d2 || (d1 == d2 && t1 > t2)) {
                trocar(&lista[j], &lista[j + 1]);
            }
        }
    }
    salvarSaida(lista, lista_sz);
}

// ordena por data e prioridade
void ordenarDataPrioridade(Compromisso lista[], int lista_sz) {
    int i, j;
    for (i = 0; i < lista_sz - 1; i++) {
        for (j = 0; j < lista_sz - i - 1; j++) {
            long d1 = (long)lista[j].ano * 10000 + lista[j].mes * 100 + lista[j].dia;
            long d2 = (long)lista[j+1].ano * 10000 + lista[j+1].mes * 100 + lista[j+1].dia;

            if (d1 > d2 || (d1 == d2 && lista[j].prioridade < lista[j + 1].prioridade)) {
                trocar(&lista[j], &lista[j + 1]);
            }
        }
    }
    salvarSaida(lista, lista_sz);
}

// ordena por local, prioridade e duracao (decrescente)
void ordenarLocalPrioridadeDuracao(Compromisso lista[], int lista_sz) {
    int i, j;
    for (i = 0; i < lista_sz - 1; i++) {
        for (j = 0; j < lista_sz - i - 1; j++) {
            int cmpLocal = strcmp(lista[j].local, lista[j + 1].local);
            if (cmpLocal > 0 ||
                (cmpLocal == 0 && lista[j].prioridade < lista[j + 1].prioridade) ||
                (cmpLocal == 0 && lista[j].prioridade == lista[j + 1].prioridade && lista[j].duracao < lista[j + 1].duracao)) {
                trocar(&lista[j], &lista[j + 1]);
            }
        }
    }
    salvarSaida(lista, lista_sz);
}

// remove espaços e quebras de linha do final de uma string
static void removerExtremosRedundantes(char *s) {
    int len;
    if (!s) return;
    len = strlen(s);
    while (len > 0 && (s[len-1] == '\n' || s[len-1] == '\r' || s[len-1] == ' ')) {
        s[--len] = '\0';
    }
}

// carrega compromissos do CSV para a estrutura Compromisso
int carregarCompromissos(const char *linha, Compromisso *c) {
    char copy[512];
    char *campos[10];
    int n = 0;
    char *token;

    strncpy(copy, linha, sizeof(copy) - 1);
    copy[sizeof(copy) - 1] = '\0';

    token = strtok(copy, ";");
    while (token && n < 10) {
        campos[n++] = token;
        token = strtok(NULL, ";");
    }

    if (n < 10) return 0;

    c->ano = atoi(campos[0]);
    c->mes = atoi(campos[1]);
    c->dia = atoi(campos[2]);
    c->hora = atoi(campos[3]);
    c->minuto = atoi(campos[4]);
    c->duracao = atof(campos[5]);
    c->prioridade = atoi(campos[6]);

    strncpy(c->nome, campos[7], 99);
    strncpy(c->descricao, campos[8], 199);
    strncpy(c->local, campos[9], 99);
    
    removerExtremosRedundantes(c->local);

    return 1;
}

int main() {
    Compromisso lista[MAX];
    int lista_sz = 0;
    int op;
    char linha[512];
    FILE *arq = fopen("entrada.csv", "r");
    
    if (arq != NULL) {
        while (fgets(linha, sizeof(linha), arq) && lista_sz < MAX) {
            if (carregarCompromissos(linha, &lista[lista_sz])) {
                lista_sz++;
            }
        }
        fclose(arq);
    }

    do {
        printf("\n>>> MENU DA AGENDA (%d/%d)\n", lista_sz, MAX);
        printf("1 - Adicionar compromisso\n");
        printf("2 - Remover compromisso\n");
        printf("3 - Ordenar por data\n");
        printf("4 - Ordenar por data e hora\n");
        printf("5 - Ordenar por data e prioridade\n");
        printf("6 - Ordenar por local, prioridade e duracao (decrescente)\n");
        printf("0 - Sair\n");
        printf("Opcao: ");
        if (scanf("%d", &op) != 1) break;

        switch (op) {
            case 1: addCompromisso(lista, &lista_sz); break;
            case 2: removCompromisso(lista, &lista_sz); break;
            case 3: ordenarData(lista, lista_sz); break;
            case 4: ordenarDataHora(lista, lista_sz); break;
            case 5: ordenarDataPrioridade(lista, lista_sz); break;
            case 6: ordenarLocalPrioridadeDuracao(lista, lista_sz); break;
            case 0: printf("Programa Finalizado!\n"); break;
        }
    } while (op != 0);

    return 0;
}
